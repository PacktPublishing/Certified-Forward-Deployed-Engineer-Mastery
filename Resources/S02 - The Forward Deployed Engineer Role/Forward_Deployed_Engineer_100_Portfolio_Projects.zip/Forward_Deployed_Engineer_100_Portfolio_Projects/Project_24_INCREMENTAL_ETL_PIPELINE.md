# Project 24: Incremental ETL Pipeline

## Project Summary

**Goal:** Load only data that has changed since the previous run.

**FDE portfolio focus:** data quality, lineage, deterministic transformations, and auditability.

This project should be presented as a small customer deployment rather than a coding exercise. The final repository should make it easy for a reviewer to understand the customer problem, the architecture, the implementation decisions, the demo, the operational metrics, and the business outcome.

---

## 1. Customer Scenario

Imagine a mid-size enterprise has asked you to solve the following problem:

> Load only data that has changed since the previous run.

The current process is partially manual, inconsistent, difficult to audit, or too slow to scale. Your job as the Forward Deployed Engineer is to discover the workflow, define a smallest useful solution, integrate it with realistic systems, deploy a working version, and prove value with measurable outcomes.

### Primary users

- Business user who performs or owns the workflow
- Operations/admin user who needs visibility and exception handling
- Engineering/security stakeholder who cares about reliability, access, and auditability

### Success criteria

- Ingest messy source data.
- Validate and transform it deterministically.
- Produce auditable outputs and quality metrics.
- Measure at least four metrics such as **rows processed, rejected-row rate, data-quality score, runtime**.

---

## 2. Recommended Technology Stack

Python 3.11+, pandas, DuckDB or PostgreSQL, SQLAlchemy, FastAPI for inspection endpoints, pytest

Keep the first version inexpensive and reproducible. Prefer synthetic/sample data and mock adapters where a real enterprise credential would otherwise be required.

### Local setup

Use an isolated Python environment so the project is reproducible:

```bash
python -m venv .venv
source .venv/bin/activate        # macOS/Linux
# .venv\Scripts\activate       # Windows PowerShell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Create `requirements.txt` from the recommended stack for this project. Keep package versions pinned once the project is working so future reviewers can reproduce your environment.

Create environment configuration from a safe template:

```bash
cp .env.example .env             # macOS/Linux
# copy .env.example .env         # Windows
```

Never place real customer credentials or private data in the repository. Use synthetic data and mock integrations for the public portfolio version.


---

## 3. Suggested Repository Structure

```text
src/
  ingestion/
  validation/
  transforms/
  loading/
  reports/
data/raw/
data/sample/
tests/
docs/
README.md
requirements.txt
```

You can adjust the exact folders, but keep business logic separate from API/UI code and keep tests and documentation first-class.

---

## 4. Step-by-Step Implementation

### Step 1: Track a high-water mark such as updatedat or source...

Track a high-water mark such as `updated_at` or source sequence ID.

### Step 2: Prove that rerunning the pipeline only processes changed/new rows...

Prove that rerunning the pipeline only processes changed/new rows and is safe after partial failure.

### Step 3: Document the source schema, target schema, data owner, refresh...

Document the source schema, target schema, data owner, refresh frequency, and known quality problems.

### Step 4: Create reproducible sample source data containing missing values, duplicates...

Create reproducible sample source data containing missing values, duplicates, malformed records, and edge cases.

### Step 5: Implement ingestion as a separate stage and save raw...

Implement ingestion as a separate stage and save raw input unchanged for traceability.

### Step 6: Implement validation rules and produce a machine-readable quality report

Implement validation rules and produce a machine-readable quality report.

### Step 7: Build transformations as small testable functions and make them...

Build transformations as small testable functions and make them idempotent.

### Step 8: Load clean outputs to DuckDB/PostgreSQL and track row counts...

Load clean outputs to DuckDB/PostgreSQL and track row counts, rejects, and transformation timestamps.

### Step 9: Add tests for schema evolution, duplicates, null handling, and...

Add tests for schema evolution, duplicates, null handling, and reruns.

### Step 10: Create a dashboard or report showing pipeline status, quality...

Create a dashboard or report showing pipeline status, quality metrics, and before/after examples.

---

## 5. Minimum Functional Demo

Your v1 should let a reviewer complete one realistic workflow without reading the code first.

- A 60–90 second screen recording showing the main **Incremental ETL Pipeline** workflow end to end.
- One architecture diagram in `docs/architecture.png` or Mermaid inside the README.
- Three to five screenshots: input/problem state, processing/decision view, output, metrics, and one failure/exception case.
- A `sample_data/` or equivalent folder containing safe synthetic data.
- A short 'What I would change for production' section demonstrating engineering judgment.


### Demo script

1. Start with the customer pain point in one sentence.
2. Show the starting data/request/event.
3. Run it through the system.
4. Show the decision, output, or action and the evidence behind it.
5. Demonstrate one exception, failure, or human-review path.
6. End on the metrics page and explain the business impact.

---

## 6. Testing Checklist

At minimum, add automated tests for:

- One normal/happy-path scenario
- Invalid or missing input
- Boundary/edge cases
- Dependency or integration failure
- Authorization or policy failure when applicable
- Duplicate/retry behavior when applicable
- One regression case discovered while building

Run tests with:

```bash
pytest -q
```

Add a CI workflow later if desired, but the repository should always be runnable locally first.

---

## 7. Metrics to Capture

Create a small metrics table or dashboard containing a baseline and a result. Suitable metrics include:

- Technical: latency, error rate, throughput, retry rate, resource/model usage
- Quality: accuracy, retrieval quality, task success, correction rate, false positives/negatives
- Workflow: cycle time, manual touches, backlog, exception rate, SLA attainment
- Business: hours saved, cost per case, conversion/containment rate, avoided errors, estimated annual value

Do not invent impressive numbers. If you use synthetic data, label the results as **simulated portfolio metrics** and explain the assumptions.

---

## 8. Security and Production Readiness

Before calling the project complete:

- Keep secrets in environment variables and provide `.env.example` with placeholder names only.
- Validate all external input.
- Avoid logging sensitive payloads.
- Add authentication/authorization where the workflow exposes protected data or actions.
- Add request/job correlation IDs for traceability.
- Make external actions idempotent where retries are possible.
- Document timeout, retry, and failure behavior.
- State clearly which pieces are demo-grade and what production hardening would be required.


---

## 8.1 Deployment Checklist

For the portfolio version, deployment can be to any environment you control. The important FDE skill is making the deployment repeatable and observable.

1. Add a `/health` endpoint for API-based projects and verify dependent services explicitly.
2. Move runtime configuration to environment variables.
3. Use a production process command appropriate to the app, for example `uvicorn app.main:app --host 0.0.0.0 --port $PORT` for FastAPI.
4. Run database/schema initialization as a repeatable command rather than a manual edit.
5. Seed only synthetic demo data in public environments.
6. Run a smoke test immediately after deployment: health check, primary workflow, one failure path, and authentication check if applicable.
7. Capture the deployed URL or demo video in the README. If the live environment is later removed, the repository should still be fully demonstrable locally.
8. Add a short deployment diagram showing client, application, storage, external integrations, and telemetry boundaries.


---

## 9. How to Showcase This Project on GitHub

1. Create a GitHub repository named `project-024-incremental-etl-pipeline`.
2. Add a concise repository description that explains the business problem, not just the technology.
3. Use a root `README.md` with: Problem, Users, Business Value, Architecture, Features, Demo, Setup, API/Workflow, Tests, Metrics, Security, Trade-offs, and Future Work.
4. Add `.gitignore` before the first commit. Never commit `.env`, tokens, customer data, local databases containing sensitive data, or model caches.
5. Commit in logical stages such as `chore: bootstrap project`, `feat: core workflow`, `feat: api`, `feat: ui`, `test: add scenarios`, and `docs: add demo and architecture`.
6. Create at least one issue and one pull request, even when working alone, to show a professional delivery workflow. The PR should explain scope, testing, screenshots, and trade-offs.
7. Tag a `v1.0.0` release when the portfolio version is complete and include a short release note describing what works and what remains intentionally out of scope.
8. Pin the repository on your GitHub profile only if it is among your strongest projects; otherwise link it from a portfolio index repository.



### Publish the repository

After creating an empty GitHub repository named `project-024-incremental-etl-pipeline`, publish your local project with:

```bash
git init
git add .
git commit -m "chore: initial portfolio version"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/project-024-incremental-etl-pipeline.git
git push -u origin main
```

For subsequent work, use small commits and push normally:

```bash
git add .
git commit -m "feat: describe the change"
git push
```


### Recommended README opening

```markdown
# Incremental ETL Pipeline

A Forward Deployed Engineering portfolio project that load only data that has changed since the previous run.

## Business Problem
[2–4 sentences describing the customer's current workflow and pain.]

## Outcome
[State what the working system changes and the metric you are optimizing.]

## Demo
![Demo GIF](screenshots/demo.gif)
```

### GitHub topics

Use a focused set of topics such as:

`forward-deployed-engineer`, `enterprise-ai`, `fastapi`, `python`, `systems-integration`, `portfolio-project`

Add project-specific topics only when they genuinely apply.

---

## 10. Screenshots to Include

1. **Architecture:** one readable system diagram.
2. **Primary workflow:** the most important user screen or API result.
3. **Decision/explanation:** why the system produced the result.
4. **Exception handling:** error, low-confidence, retry, or approval path.
5. **Metrics:** dashboard or report showing system/business performance.

Keep screenshots in `screenshots/` and reference them directly from the README.

---

## 11. Suggested Git Commit Sequence

```text
chore: bootstrap project-024-incremental-etl-pipeline
feat: add core domain models and sample data
feat: implement primary workflow
feat: expose api endpoints
feat: add operator/demo interface
test: cover happy path and failure scenarios
feat: add metrics and audit trail
docs: add architecture, screenshots, and demo instructions
```

---

## 12. Portfolio Story to Tell in an Interview

Use a five-part story:

1. **Discovery:** "The customer was struggling with ..."
2. **Constraint:** "The difficult part was ..."
3. **Decision:** "I chose this architecture because ..."
4. **Delivery:** "I implemented and integrated ..."
5. **Outcome:** "The measured/simulated result was ..., and the next production step would be ..."

The purpose is to demonstrate that you can bridge **customer context and engineering execution**, which is the core value of a Forward Deployed Engineer.

---

## 13. Resume / LinkedIn Project Bullet

> Built **Incremental ETL Pipeline**, an FDE portfolio deployment that load only data that has changed since the previous run. Designed the end-to-end workflow, APIs/integrations, tests, observability, and measurable success criteria, with a reproducible GitHub demo and documented production trade-offs.

---

## 14. Stretch Goals

- Add a second integration or data source.
- Add role-based access and richer audit history.
- Add performance/load testing.
- Add a formal evaluation dataset or replay harness.
- Add a CI pipeline and automated quality gates.
- Add configuration for multiple fictional customers/tenants.
- Write a short postmortem describing one failure discovered during testing and how you fixed it.

---

## Definition of Done

The project is portfolio-ready when a reviewer can:

- Understand the customer problem in under one minute.
- Run the project from documented setup instructions.
- Complete the primary workflow with sample data.
- See at least one failure/exception path.
- See tests pass.
- Inspect architecture and security decisions.
- See measurable technical and business outcomes.
- Understand exactly what you would change before a real production deployment.
